from .cancer import CancerFromICD10
from .diabetes import DiabetesFromICD10
from .psychiatric_disorder import PsychiatricDisorderFromICD10
from .suicide_attempt import SuicideAttemptFromICD10
