from .tagging_functions import tagging

__all__ = ["tagging"]
