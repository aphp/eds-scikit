from .cancer import CancerFromICD10
