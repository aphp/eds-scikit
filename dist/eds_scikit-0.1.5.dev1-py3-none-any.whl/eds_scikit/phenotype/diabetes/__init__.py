from .diabetes import DiabetesFromICD10
